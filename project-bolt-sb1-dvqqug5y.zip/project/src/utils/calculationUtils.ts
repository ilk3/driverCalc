import { CalculationData, CalculationResults } from '../types';

export const calculateEarnings = (data: CalculationData): CalculationResults => {
  // 1. Ride Pricing calculation
  const rideEarnings = calculateRideEarnings(data.rides);
  
  // 2. Unloading Points calculation (excluding first point)
  const unloadingPointsEarnings = calculateUnloadingPointsEarnings(data.unloadingPoints);
  
  // 3. Kilometer-based calculation
  const kilometerEarnings = calculateKilometerEarnings(data.kilometers);
  
  // 4. Shopping Center Unloading calculation
  const shoppingCenterEarnings = calculateShoppingCenterEarnings(data.shoppingCenters);
  
  // 5. Total Earnings calculation
  const totalEarnings = rideEarnings + unloadingPointsEarnings + kilometerEarnings + shoppingCenterEarnings;
  
  return {
    rideEarnings,
    unloadingPointsEarnings,
    kilometerEarnings,
    shoppingCenterEarnings,
    totalEarnings,
    details: {
      rides: data.rides,
      unloadingPoints: data.unloadingPoints,
      kilometers: data.kilometers,
      shoppingCenters: data.shoppingCenters
    }
  };
};

// Calculate earnings for rides
const calculateRideEarnings = (rides: number): number => {
  const rideRates = [4300, 3700, 5800];
  let total = 0;
  
  for (let i = 0; i < Math.min(rides, 3); i++) {
    total += rideRates[i];
  }
  
  return total;
};

// Calculate earnings for unloading points
const calculateUnloadingPointsEarnings = (points: number): number => {
  // First point is free, additional points are 200 RSD each
  return Math.max(0, points - 1) * 200;
};

// Calculate earnings for kilometers driven
const calculateKilometerEarnings = (kilometers: number): number => {
  return kilometers * 38;
};

// Calculate earnings for shopping center unloading
const calculateShoppingCenterEarnings = (centers: number): number => {
  return centers * 1500;
};

// Format currency with thousand separators
export const formatCurrency = (amount: number): string => {
  return amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
};