export interface CalculationData {
  rides: number;
  unloadingPoints: number;
  kilometers: number;
  shoppingCenters: number;
}

export interface CalculationResults {
  rideEarnings: number;
  unloadingPointsEarnings: number;
  kilometerEarnings: number;
  shoppingCenterEarnings: number;
  totalEarnings: number;
  details: {
    rides: number;
    unloadingPoints: number;
    kilometers: number;
    shoppingCenters: number;
  }
}