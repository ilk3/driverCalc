import React, { useState } from 'react';
import { CalculationData } from '../types';
import { ArrowRightCircleIcon } from 'lucide-react';

interface CalculatorFormProps {
  onCalculate: (data: CalculationData) => void;
  isCalculating: boolean;
}

const CalculatorForm: React.FC<CalculatorFormProps> = ({ 
  onCalculate, 
  isCalculating 
}) => {
  const [formData, setFormData] = useState<CalculationData>({
    rides: 1,
    unloadingPoints: 1,
    kilometers: 0,
    shoppingCenters: 0
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    const numValue = parseInt(value);

    if (name === 'rides' && (numValue < 1 || numValue > 3)) {
      setErrors(prev => ({ 
        ...prev, 
        [name]: 'Broj vožnji mora biti između 1 i 3' 
      }));
    } else if (numValue < 0) {
      setErrors(prev => ({ 
        ...prev, 
        [name]: `${name === 'rides' ? 'Broj vožnji' : 
                  name === 'unloadingPoints' ? 'Broj istovara' :
                  name === 'kilometers' ? 'Kilometraža' :
                  'Broj tržnih centara'} ne može biti negativan` 
      }));
    } else {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }

    setFormData(prev => ({
      ...prev,
      [name]: numValue
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const newErrors: Record<string, string> = {};
    
    if (formData.rides < 1 || formData.rides > 3) {
      newErrors.rides = 'Broj vožnji mora biti između 1 i 3';
    }
    
    if (formData.unloadingPoints < 1) {
      newErrors.unloadingPoints = 'Mora biti najmanje 1 istovar';
    }
    
    if (formData.kilometers < 0) {
      newErrors.kilometers = 'Kilometraža ne može biti negativna';
    }
    
    if (formData.shoppingCenters < 0) {
      newErrors.shoppingCenters = 'Broj tržnih centara ne može biti negativan';
    }
    
    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }
    
    onCalculate(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <p className="text-gray-600 mb-6">
        Unesite detalje vožnje da izračunate zaradu.
      </p>
      
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Broj vožnji (1-3)
          </label>
          <input
            type="number"
            name="rides"
            min="1"
            max="3"
            value={formData.rides}
            onChange={handleChange}
            className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors ${
              errors.rides ? 'border-red-500 bg-red-50' : 'border-gray-300'
            }`}
          />
          {errors.rides && (
            <p className="mt-1 text-sm text-red-600">{errors.rides}</p>
          )}
          <p className="mt-1 text-xs text-gray-500">
            Prva vožnja: 4.300 RSD, Druga vožnja: 3.700 RSD, Treća vožnja: 5.800 RSD
          </p>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Ukupan broj istovara
          </label>
          <input
            type="number"
            name="unloadingPoints"
            min="1"
            value={formData.unloadingPoints}
            onChange={handleChange}
            className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors ${
              errors.unloadingPoints ? 'border-red-500 bg-red-50' : 'border-gray-300'
            }`}
          />
          {errors.unloadingPoints && (
            <p className="mt-1 text-sm text-red-600">{errors.unloadingPoints}</p>
          )}
          <p className="mt-1 text-xs text-gray-500">
            200 RSD po istovaru (prvi istovar se ne računa)
          </p>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Ukupno pređenih kilometara
          </label>
          <input
            type="number"
            name="kilometers"
            min="0"
            value={formData.kilometers}
            onChange={handleChange}
            className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors ${
              errors.kilometers ? 'border-red-500 bg-red-50' : 'border-gray-300'
            }`}
          />
          {errors.kilometers && (
            <p className="mt-1 text-sm text-red-600">{errors.kilometers}</p>
          )}
          <p className="mt-1 text-xs text-gray-500">
            38 RSD po kilometru
          </p>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Broj istovara u tržnim centrima
          </label>
          <input
            type="number"
            name="shoppingCenters"
            min="0"
            value={formData.shoppingCenters}
            onChange={handleChange}
            className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors ${
              errors.shoppingCenters ? 'border-red-500 bg-red-50' : 'border-gray-300'
            }`}
          />
          {errors.shoppingCenters && (
            <p className="mt-1 text-sm text-red-600">{errors.shoppingCenters}</p>
          )}
          <p className="mt-1 text-xs text-gray-500">
            1.500 RSD po tržnom centru
          </p>
        </div>
      </div>

      <button
        type="submit"
        disabled={isCalculating || Object.keys(errors).length > 0}
        className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 focus:ring-4 focus:ring-blue-300 text-white font-medium py-3 px-4 rounded-lg transition-colors disabled:opacity-70 disabled:cursor-not-allowed"
      >
        {isCalculating ? (
          <>
            <span className="w-5 h-5 border-t-2 border-r-2 border-white rounded-full animate-spin mr-2"></span>
            Računanje...
          </>
        ) : (
          <>
            Izračunaj zaradu <ArrowRightCircleIcon size={20} />
          </>
        )}
      </button>
    </form>
  );
};

export default CalculatorForm;