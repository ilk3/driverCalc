import React from 'react';
import { CalculationResults as ResultsType } from '../types';
import { formatCurrency } from '../utils/calculationUtils';
import { RefreshCwIcon, TruckIcon, MapPinIcon, UploadIcon as RoadIcon, ShoppingBagIcon } from 'lucide-react';

interface CalculationResultsProps {
  results: ResultsType;
  onReset: () => void;
}

const CalculationResults: React.FC<CalculationResultsProps> = ({ results, onReset }) => {
  const {
    rideEarnings,
    unloadingPointsEarnings,
    kilometerEarnings,
    shoppingCenterEarnings,
    totalEarnings,
    details
  } = results;

  return (
    <div className="animate-fadeIn">
      <div className="mb-6">
        <h2 className="text-xl font-bold text-gray-800 mb-2">Rezultati zarade</h2>
        <p className="text-gray-600">
          Pregled vaše izračunate zarade:
        </p>
      </div>

      <div className="space-y-4 mb-6">
        <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
          <div className="flex items-start gap-3">
            <div className="bg-blue-100 p-2 rounded-full text-blue-600 mt-1">
              <TruckIcon size={20} />
            </div>
            <div className="flex-1">
              <h3 className="font-medium text-gray-800">Zarada od vožnji</h3>
              <p className="text-sm text-gray-500">{details.rides} vožnja/e</p>
              <p className="font-semibold text-lg mt-1">{formatCurrency(rideEarnings)} RSD</p>
            </div>
          </div>
        </div>

        <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
          <div className="flex items-start gap-3">
            <div className="bg-blue-100 p-2 rounded-full text-blue-600 mt-1">
              <MapPinIcon size={20} />
            </div>
            <div className="flex-1">
              <h3 className="font-medium text-gray-800">Zarada od istovara</h3>
              <p className="text-sm text-gray-500">{details.unloadingPoints} istovar(a) ({details.unloadingPoints > 1 ? `${details.unloadingPoints - 1} plaćen(ih)` : 'prvi besplatan'})</p>
              <p className="font-semibold text-lg mt-1">{formatCurrency(unloadingPointsEarnings)} RSD</p>
            </div>
          </div>
        </div>

        <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
          <div className="flex items-start gap-3">
            <div className="bg-blue-100 p-2 rounded-full text-blue-600 mt-1">
              <RoadIcon size={20} />
            </div>
            <div className="flex-1">
              <h3 className="font-medium text-gray-800">Zarada po kilometru</h3>
              <p className="text-sm text-gray-500">{details.kilometers} kilometara</p>
              <p className="font-semibold text-lg mt-1">{formatCurrency(kilometerEarnings)} RSD</p>
            </div>
          </div>
        </div>

        <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
          <div className="flex items-start gap-3">
            <div className="bg-blue-100 p-2 rounded-full text-blue-600 mt-1">
              <ShoppingBagIcon size={20} />
            </div>
            <div className="flex-1">
              <h3 className="font-medium text-gray-800">Zarada od tržnih centara</h3>
              <p className="text-sm text-gray-500">{details.shoppingCenters} tržni(h) centar(a)</p>
              <p className="font-semibold text-lg mt-1">{formatCurrency(shoppingCenterEarnings)} RSD</p>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-5 mb-6">
        <h3 className="text-lg font-bold text-blue-800 mb-1">Ukupna zarada</h3>
        <p className="text-3xl font-bold text-blue-900">{formatCurrency(totalEarnings)} RSD</p>
      </div>

      <button
        onClick={onReset}
        className="w-full flex items-center justify-center gap-2 bg-gray-600 hover:bg-gray-700 focus:ring-4 focus:ring-gray-300 text-white font-medium py-3 px-4 rounded-lg transition-colors"
      >
        <RefreshCwIcon size={20} /> 
        Novi proračun
      </button>
    </div>
  );
};

export default CalculationResults;