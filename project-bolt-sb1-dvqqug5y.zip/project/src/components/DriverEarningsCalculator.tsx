import React, { useState } from 'react';
import CalculatorForm from './CalculatorForm';
import CalculationResults from './CalculationResults';
import { TruckIcon } from 'lucide-react';
import { CalculationData, CalculationResults as ResultsType } from '../types';
import { calculateEarnings } from '../utils/calculationUtils';

const DriverEarningsCalculator: React.FC = () => {
  const [calculationResults, setCalculationResults] = useState<ResultsType | null>(null);
  const [isCalculating, setIsCalculating] = useState<boolean>(false);

  const handleCalculate = (data: CalculationData) => {
    setIsCalculating(true);
    
    setTimeout(() => {
      const results = calculateEarnings(data);
      setCalculationResults(results);
      setIsCalculating(false);
    }, 600);
  };

  const handleReset = () => {
    setCalculationResults(null);
  };

  return (
    <div className="w-full max-w-2xl">
      <div className="bg-white rounded-xl shadow-lg overflow-hidden">
        <div className="bg-blue-900 text-white p-5 flex items-center gap-3">
          <TruckIcon size={28} />
          <h1 className="text-2xl font-bold">Kalkulator Zarade Vozača</h1>
        </div>
        
        <div className="p-6">
          {calculationResults ? (
            <CalculationResults 
              results={calculationResults} 
              onReset={handleReset} 
            />
          ) : (
            <CalculatorForm 
              onCalculate={handleCalculate} 
              isCalculating={isCalculating} 
            />
          )}
        </div>
      </div>

      <div className="text-center mt-6 text-gray-500 text-sm">
        © {new Date().getFullYear()} Kalkulator Zarade Vozača
      </div>
    </div>
  );
};

export default DriverEarningsCalculator;