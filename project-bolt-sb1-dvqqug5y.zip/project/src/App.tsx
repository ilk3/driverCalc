import React from 'react';
import DriverEarningsCalculator from './components/DriverEarningsCalculator';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 flex flex-col items-center justify-center p-4 sm:p-6">
      <DriverEarningsCalculator />
    </div>
  );
}

export default App;